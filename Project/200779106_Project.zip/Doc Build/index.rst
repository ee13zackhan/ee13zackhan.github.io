.. Site Locator documentation master file, created by
   sphinx-quickstart on Tue May 10 18:21:25 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Site Locator's documentation!
========================================

.. toctree::
   :maxdepth: 2
   

    SiteLocator
Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
