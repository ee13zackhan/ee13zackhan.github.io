.. Agent Based Model documentation master file, created by
   sphinx-quickstart on Tue Mar  8 12:53:00 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Agent Based Model's documentation!
=============================================

.. toctree::
   :maxdepth: 2

   agentframework
   enviro


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
